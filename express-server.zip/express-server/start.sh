#!/bin/bash
nohup npm run start &